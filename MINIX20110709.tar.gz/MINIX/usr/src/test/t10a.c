#include <stdlib.h>

_PROTOTYPE(int main, (void));

int main()
{
  exit(0);
}
