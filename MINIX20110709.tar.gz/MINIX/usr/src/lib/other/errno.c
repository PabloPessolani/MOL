#include <lib.h>
/* errno.c - declare variable errno             Author: F. Meulenbroeks */

int errno = 0;
