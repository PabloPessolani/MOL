/* This library provides generic watchdog timer management functionality.
 * See the comments in <timers.h> for details.
 */

#include <timers.h>		/* definitions and function prototypes */
#define NULL 	(void *) 0	/* null-pointer definition */

