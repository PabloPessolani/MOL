#include	<stdio.h>
#include	<stdlib.h>

double
strtod(const char *p, char **pp)
{
	fprintf(stderr,"cannot print floating point\n");
	exit(EXIT_FAILURE);
}
