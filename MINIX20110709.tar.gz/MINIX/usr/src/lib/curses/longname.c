#include <curses.h>
#include "curspriv.h"

/****************************************************************/
/* Longname() returns a pointer to a string describing the	*/
/* User terminal.						*/
/****************************************************************/

char *longname()
{
  return("not implemented");
}
