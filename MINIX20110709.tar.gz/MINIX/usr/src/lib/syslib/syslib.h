/*	syslib.h - System library common definitions.	*/

#define _SYSTEM

#include <lib.h>
#include <minix/com.h>
#include <minix/syslib.h>
