extern int pci_procnr;
