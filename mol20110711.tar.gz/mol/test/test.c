/*
 * test.c
 */

#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>



int main(int argc,char *argv[])
{
	int pid;

	pid = getpid();
	printf("TEST: getpid returns = %d\n", pid);
	exit(0);
}
