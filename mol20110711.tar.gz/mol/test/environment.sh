#! /bin/sh
export LD_PRELOAD=$LD_PRELOAD:./fakelib.so
