_PROTOTYPE( int env_parse, (char *env, char *fmt, int field,
			long *param, long min, long max)		);
_PROTOTYPE( void env_panic, (char *env)					);
_PROTOTYPE( int env_prefix, (char *env, char *prefix)			);
