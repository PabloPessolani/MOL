
#define _MOLIPC_H 1

/*----------------------- MOL IPC functions prototyping ----------*/
_PROTOTYPE(int ipc_open,	(mol_proc_t *mpp));
_PROTOTYPE(int ipc_send, 	(ipc_t *ipc));
_PROTOTYPE(int ipc_rcv, 	(ipc_t *ipc));
_PROTOTYPE(int ipc_close,	(mol_proc_t *mpp));
_PROTOTYPE(int data_rcv,	(ipc_t *ipc, char *bufptr, int nbytes));
_PROTOTYPE(int data_send,	(ipc_t *ipc, char *bufptr, int nbytes));

 