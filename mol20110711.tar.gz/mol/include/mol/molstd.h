/* The molstd.h header contains MOL System calls renaming */

#ifdef MOL

#define _MOLSTD_H

#ifndef _CONFIG_H
#include "./minix/config.h"
#endif /* _CONFIG_H */

#ifndef _ANSI_H
#include "../ansi.h"
#endif /* _ANSI_H */

#ifndef _MOLLIB_H
#include "mollib.h"
#endif /* _CONFIG_H */

#endif /* MOL */

