/******************************************************************/
/*				MOLMINIX.H						*/
/******************************************************************/
#define MM                 PM_PROC_NR
#define FS                 FS_PROC_NR
#define SLOT_FREE        0x01    /* process slot is free */
#define ACKNOWLEDGE      0x80    /*  process slot is free */
#define P_NAME_LEN        8
typedef int proc_nr_t;           /* process table entry number */




