/* The mollib.h header contains Auxiliary functions and System Calls prototyping */

#define _MULTI_THREADED

#define _MOLLIB_H 1

#define MOLKERNEL_PORT 	8000
#define MOLKERNEL_ADDR	"127.0.0.222"

#define MOLPM_PORT 	8100
#define MOLPM_ADDR	"127.0.0.222"

#define MAXHELLO	2	/*  # of ticks to enable HELLO for a process */
#define MAXDEAD		2	/* Max # of HELLO counts to consider a dead process */
#define MAX_BLOCK_SIZE		 4096

#ifdef MOLDBG
 #define MOLDEBUG(x, args ...) fprintf(stderr, "DEBUG %s:%s:%u: " \
 x, __FILE__, __FUNCTION__ ,__LINE__, ## args) 
#else 
#define MOLDEBUG(x, args ...)
 #endif 

 #define MOLPRINT(x, args ...) fprintf(stdout, "%s:%s:%u: " \
 x, __FILE__, __FUNCTION__ ,__LINE__, ## args) 


#define MOLERROR(T,X) 	do { 			\
				fprintf(stderr,"ERROR %s:%s:%u: ",__FILE__, __FUNCTION__ ,__LINE__);\
				fprintf(stderr,T,X);	\
				return(X);	\
				}while(0)

#define MOLLOG(txt ...)	syslog(LOG_INFO, txt ...)  

#ifndef _ANSI_H
#include "../ansi.h"
#endif

#ifndef _IPC_H
#include "../minix/ipc.h"
#endif

/*
#ifndef _LINUX_IN_H
#include  "/usr/include/linux/in.h"
#endif
*/

typedef struct	{
		int			code;		/* SEND, RECEIVE, SENDREC, NOTIFY, OK */
		int			spid;		/* LINUX sender's PID */
		unsigned long	seq;	/* sequence number */
        int			p_nr;		/* kminixd process slot number */
        int			p_endpoint;	/* kminixd process endpoint */	
        int			srcdst;	/* minix source (receive) or dest (send,notify) endpoint */ 	
		message		mnxmsg;	/* MINIX msg	*/
		} mol_msg_t;

typedef struct  {
		int 	 	socket;         /* Socket 		*/
		struct sockaddr_in addr;   	/* AF_INET 		*/
		struct sockaddr_in svr_addr;   	/* AF_INET server	*/
		int	 		addrlen;	/* Address Length	*/
		mol_msg_t 	molmsg;		/* mol message  	*/
		} ipc_t;

typedef struct  {
		ipc_t 			kipc;	/*  send/receive kernel message	*/	
		ipc_t 			sipc;	/* send to ipc server message		*/	
		ipc_t 			ripc;	/* receive from ipc server message 	*/
		pid_t 			p_pid;	/* process pid		*/
		proc_nr_t 		p_nr;		/* number of this process (for fast access) */
		int 			p_endpoint;	/* endpoint number, generation-aware */
		unsigned long 	pseq;	/* process sequence # 	*/
		unsigned long 	kseq;	/* kminixd sequence # 	*/
		struct sigaction sa;	/* signal action		*/
		char      		p_name[P_NAME_LEN];	/* process name 	*/
		} mol_proc_t;
		
/* we store handler installed by minix user code */ 
typedef struct {
	  unsigned int installed;
	  struct sigaction sa;
	} mnx_sa_t;

#define NO_EINTR(stmt) while ((stmt) == -1 && errno == EINTR);

typedef int (*lnx_getpid_t)(void); 

_PROTOTYPE(int mnx_bind,	(mol_proc_t  *mpp));
_PROTOTYPE(int mnx_unbind,	(mol_proc_t  *mpp));
_PROTOTYPE(int mnx_send,	(int dest, message *m_ptr,mol_proc_t  *mpp));
_PROTOTYPE(int mnx_receive,	(int src, message *m_ptr,mol_proc_t  *mpp));
_PROTOTYPE(int mnx_sendrec,	(int src_dest, message *m_ptr,mol_proc_t  *mpp));
_PROTOTYPE(int mnx_notify,	(int dest, message *m_ptr, mol_proc_t  *mpp));

#define OK		0
#define NOTOK   	1

#define DOREPLY	0
#define DONTREPLY	1

#define FALSE	0
#define TRUE	1

/*--------------------------------  MOL OPERATION CODES ----------------------------*/
#define BIND	0xFF01
#define UNBIND  	0xFF02

#define HELLO	0xFF03

#define COPYIN  	0xFF04
#define COPYOUT  	0xFF05
#define COPYEND  	0xFF06

typedef int (*lnx_FP_t)();

 