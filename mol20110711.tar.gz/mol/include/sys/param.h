/*
sys/param.h
*/

#define MAXHOSTNAMELEN  256	/* max hostname size */
