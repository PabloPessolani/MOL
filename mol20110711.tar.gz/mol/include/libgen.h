/*
libgen.h
*/

#include <ansi.h>

/* Open Group Base Specifications Issue 6 (not complete) */
_PROTOTYPE( char *basename, (char *_path)				);

