/*
netinet/tcp.h
*/

#define TCP_NODELAY	0x01	/* Avoid coalescing of small segments */
