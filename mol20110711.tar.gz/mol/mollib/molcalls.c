/******************************************************************
			MOLCALLS.C
*******************************************************************/

#define _GNU_SOURCE 
#include <stdio.h>
#include <stdint.h> 
#include <dlfcn.h> 
#include <unistd.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <time.h>
#include <signal.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

/*---------------------- MINIX HEADERS ---------------------------*/
#include "../include/minix/config.h"
#include "../include/minix/com.h"
#include "../include/minix/callnr.h"
#include "../include/minix/endpoint.h" 	

/*---------------------- MOL HEADERS ---------------------------*/
#include "../include/mol/molminix.h"
#define MOLDBG 1
#include "../include/mol/mollib.h"
#include "../include/mol/molipc.h"

void *container_thread(void *arg);

#define _sendrec(to, msg) mnx_sendrec(to, msg, mpp)

/*---------- GLOBAL data structure for the process -----*/
extern mol_proc_t mnxproc;
extern mnx_sa_t mnx_sa[NSIG];
extern lnx_FP_t lnx_sc[NCALLS];
extern pthread_t 	cont_tid;			/* Container  thread ID  */

/*-------------------------------------------------------------------
			MINIX SYSCALL	
--------------------------------------------------------------------*/
int _syscall(int who, int syscallnr, message *msgptr)
{
  int status;
  int who_e;
  mol_proc_t *mpp;
  
  mpp = &mnxproc;

  msgptr->m_source = mpp->p_endpoint;  
  msgptr->m_type = syscallnr;
  who_e = _ENDPOINT(0, who); /* GENERATION=0 */

  status = _sendrec(who_e, msgptr);
  if (status != 0) 
	msgptr->m_type = status;
  
  if (msgptr->m_type < 0) 
	{
	errno = -msgptr->m_type;
	return(-1);
  	}
  return(msgptr->m_type);
}

/*-------------------------------------------------------------------
			GETPID WRAPPER		
--------------------------------------------------------------------*/
pid_t  _getpid(void) 
{
  message m;
  return(_syscall(MM, GETPID, &m)); 
}


/*-------------------------------------------------------------------
			FALSO GETPID		
--------------------------------------------------------------------*/
pid_t getpid(void ) /* falso getpid de LINUX con el mismo nombre */
{
	typedef int (*FP_getpid)(void); 

	/* getpid original de LINUX */
	//FP_getpid org_getpid = dlsym(((void *) -1l), "getpid"); 
	lnx_sc[GETPID] = dlsym(((void *) -1l), "getpid");
	
	/* getpid de MINIX definido en la biblioteca lib/posix */
	return (_getpid ()); 
	
	/* the calling to the real linux function would be
			return( (lnx_sc[FP_GETPID])()  );
	*/
}

/*-------------------------------------------------------------------
			FORK WRAPPER		
--------------------------------------------------------------------*/
pid_t  _fork(void) 
{
	message m;
	pid_t mpid;
	pid_t lpid;
	mol_proc_t *mpp;
	int rcode;
	int idx;
	
MOLDEBUG("FORK WRAPPER\n");
	mpp = &mnxproc;
	
	mpid = _syscall(MM, FORK, &m);
	if( mpid < 0)
		MOLERROR("syscall error=%d\n",mpid);
MOLDEBUG("MINIX pid=%d\n",mpid);

	lpid = lnx_sc[FORK]();
MOLDEBUG("LINUX pid=%d\n",lpid);

	if( lpid < 0)
		MOLERROR("linux fork error=%d\n",lpid);
	
	if( lpid == 0)	/* LINUX SON */
		{
		lnx_sc[GETPID] = dlsym(((void *) -1l), "getpid");
		mpp->p_pid = lnx_sc[GETPID](); /* original LINUX getpid()	*/
		sprintf(mpp->p_name,"MX%05d",mpp->p_pid);
MOLDEBUG("p_name=%s \n",mpp->p_name);

		/*--------------- Close FATHER communications -------------*/
		rcode = ipc_close(mpp);
		if(rcode != OK)
			MOLERROR("ipc_close error= %d \n",rcode);	
		
		/*------- initialize IPC communications --------------*/
		rcode = ipc_open(mpp);
		if(rcode != OK)
			MOLERROR("error=%d \n",rcode);

		/*------- Register the process on MOLKERNEL-------------*/
		rcode = mnx_bind(mpp);
		if(rcode != OK)
			MOLERROR("error=%d \n",rcode);

		/*---------------- Start Conteiner  thread  ----------------------*/
		rcode = pthread_create(&cont_tid, NULL, container_thread, &idx);
		if (rcode != 0)
			MOLERROR("pthread_create rcode=%d\n",rcode);
		return(mpid);
		}
	mpid = lpid;	/*ESTO ES SOLO PARA PRUEBA*/
 	
	return(mpid);	/* PID returned to FATHER */
}


/*-------------------------------------------------------------------
			FALSO FORK		
--------------------------------------------------------------------*/
pid_t fork(void ) /* falso getpid de LINUX con el mismo nombre */
{
	pid_t mpid;

	typedef int (*FP_fork)(void); 

	/* fork  original de LINUX */
	lnx_sc[FORK] = dlsym(((void *) -1l), "fork");
	
	/* fork de MINIX definido en la biblioteca lib/posix */
	mpid = _fork ();
MOLDEBUG("FALSO FORK pid=%d\n",mpid);
	
	return(mpid);
	
}

/*-------------------------------------------------------------------
			FALSO SIGNAL		
--------------------------------------------------------------------*/
/*
	mol_signal:
	registra el handler de codigo MINIX para eventual ejecuci�n controlada.
*/
sig_t mol_signal(int sig, sig_t func)
{
	struct sigaction sa;
	
	sa.sa_handler = func;
	
	MOLPRINT("Registering routine for signal %d on MoL...\t", sig);
	mnx_sa[sig-1].sa = sa;
	mnx_sa[sig-1].installed = 1; /* now we know we have to execute this when signal arrives */
	
	return(0);
}


sig_t signal(int sig, sig_t func)
{

	lnx_sc[SIGNAL] = dlsym(((void *) -1l), "signal");
	/* sigaction de MINIX definido en la biblioteca lib/posix */
	return (mol_signal (sig, func)); 
	
	/* the calling to the real linux function would be
			return( (lnx_sc[FP_SIGNAL])(sig,func)  );
	*/
}






