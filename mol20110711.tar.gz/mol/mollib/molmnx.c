/******************************************************************
			MOLMNX.C
These functions are executed before and after MINIX main
mol_before: initialize CONTROL and IPC channels
mol_before: initialize MOL Signal handlers
mol_before: starts container thread
mol_before: intercepts MINIX system calls and redirect them 
            to the MOL library
*******************************************************************/

#define _GNU_SOURCE 
#include <stdio.h>
#include <stdint.h> 
#include <dlfcn.h> 
#include <unistd.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <time.h>
#include <signal.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

/*---------------------- MINIX HEADERS ---------------------------*/
#include "../include/minix/config.h" 	
#include "../include/minix/endpoint.h"		
#include "../include/minix/callnr.h"		
#include "../../kernel/ipc.h"		

/*---------------------- MOL HEADERS ---------------------------*/
#define MOLDBG 1
#include "../include/mol/molminix.h"
#include "../include/mol/mollib.h"
#include "../include/mol/molipc.h"

void sigusr1(int sig);
void setSigHandler(int sig);
static void molSigHandler(int sig);
void defaultSigHandler(int sig);
void handle_SIGFPE(void);
void handle_SIGINT(void);
void *container_thread(void *arg);
int send_ack(int code);

/*---------- GLOBAL data structure for the process -----*/
mol_proc_t  mnxproc;			/* MOL Process data	*/
pthread_t 	cont_tid;			/* Container  thread ID  */
lnx_getpid_t	lnx_sc_getpid; 	/* original LINUX getpid system call address */
lnx_FP_t lnx_sc[NCALLS]; 		/* we store original linux stealth library functions addresses */
struct sigaction lnx_sa[NSIG]; 	/* we store original linux sigactions here to exec before dying on a terminating signal (eg. SIGILL) */
mnx_sa_t mnx_sa[NSIG];

char buffer[MAX_BLOCK_SIZE];				/* Pointer to the IN/OUT buffer for COPYIN/COPYOUT */

/************************************************************/
/* 		MOL BEFORE/AFTER MAIN FUNCTIONS		*/
/************************************************************/

/*----------------------------------------------------------*/
/*			function BEFORE main		*/
/*----------------------------------------------------------*/
void mol_before(void) __attribute__((constructor));
void mol_before(void) 
{
	int rcode;
	mol_proc_t *mpp;
	int i;
	int idx;


MOLDEBUG("function before main\n");
	mpp = &mnxproc;

	/*get the address of the intercepted funcions */
	lnx_sc_getpid = dlsym(((void *) -1l), "getpid"); 
	mpp->p_pid = lnx_sc_getpid(); /* original LINUX getpid()	*/
MOLDEBUG("p_pid %d\n", mpp->p_pid);

	sprintf(mpp->p_name,"MX%05d",mpp->p_pid);
MOLDEBUG("p_name=%s \n",mpp->p_name);	

	/*------- initialize IPC communications --------------*/
	rcode = ipc_open(mpp);
	if(rcode != OK)
		MOLERROR("error=%d \n",rcode);
		
	/*------- Sets the Signal Action for SIGURSR1---------*/
	sigemptyset(&mpp->sa.sa_mask);
	mpp->sa.sa_flags = SA_RESTART;
	mpp->sa.sa_handler = sigusr1;
	if (sigaction(SIGUSR1, &mpp->sa, NULL) == -1)
		MOLERROR("sigaction for SIGUSR1\n", -1);

	/*------- Register the process on MOLKERNEL-------------*/
	rcode = mnx_bind(mpp);
	if(rcode != OK)
		MOLERROR("error=%d \n",rcode);
		
	/*------- Sets the Signal Action for killer signals---------*/
	
	/* init sa arrays */
	for(i = 0; i < NSIG; i++)
		mnx_sa[i].installed = 0;
		
	/* set default MoL handler for all signals */
	for(i = 1; i <= NSIG; i++)
		setSigHandler(i);
	
	/*---------------- Start Conteiner  thread  ----------------------*/

	rcode = pthread_create(&cont_tid, NULL, container_thread, &idx);
	if (rcode != 0)
		MOLERROR("pthread_create rcode=%d\n",rcode);

} 

/*----------------------------------------------------------*/
/*			function AFTER main		*/
/*----------------------------------------------------------*/
void mol_after(void) __attribute__((destructor));
void mol_after(void) 
{ 
	int rcode;
	mol_proc_t *mpp;

MOLDEBUG("function after main\n"); 
	mpp = &mnxproc;

	/*--------------- End IPC communications -------------*/
MOLDEBUG("Cancelling Container thread\n");
	rcode = pthread_cancel(cont_tid);
	if(rcode != OK)
		MOLERROR("pthread_cancel error= %d \n",rcode);
		
	/*------- Deregister the process on MOLKERNEL-----------*/
	rcode = mnx_unbind(mpp);
	if(rcode != OK)
		MOLERROR("error=%d \n",rcode);

	rcode = ipc_close(mpp);
	if(rcode != OK)
		MOLERROR("ipc_close error= %d \n",rcode);
	
	
} 
/*----------------------------------------------------------*/
/*	CONTAINER THREAD FUNCTION	      */
/*----------------------------------------------------------*/
void *container_thread(void *arg)
{
    int rcode;
	int rqst;
	int nbytes;
	ipc_t *kipcp;
	
	kipcp=&mnxproc.kipc;
	
	MOLDEBUG("CONTAINER THREAD Starting\n");

	while (TRUE) 
		{
MOLPRINT("Waiting Request message...\n");
		rcode = ipc_rcv(kipcp);
		if ( rcode != OK) continue;
		
		rqst 	= kipcp->molmsg.code;
		switch(rqst)
			{
			case HELLO:
MOLDEBUG("HELLO message received\n");
				send_ack( (HELLO | ACKNOWLEDGE));
				break;
			case COPYIN:
				nbytes = kipcp->molmsg.mnxmsg.m1_i1;
MOLDEBUG("COPYIN message received bytes:%d\n", nbytes);
				if( nbytes > MAX_BLOCK_SIZE || nbytes < 0 )
					{
MOLPRINT("COPYIN ERROR nbytes = %d\n",nbytes);
					kipcp->molmsg.mnxmsg.m_type = EINVAL;
					send_ack( (COPYIN | ACKNOWLEDGE));
					}
				else
					{
					kipcp->molmsg.mnxmsg.m_type = OK;
					send_ack( (COPYIN | ACKNOWLEDGE));
					rcode = data_rcv(kipcp,(char*) buffer, nbytes);
					}
				break;
			case COPYOUT:
				nbytes = kipcp->molmsg.mnxmsg.m1_i1;
MOLDEBUG("COPYOUT message received bytes:%d\n", nbytes);
				if( nbytes > MAX_BLOCK_SIZE || nbytes < 0 )
					{
MOLPRINT("COPYOUT ERROR nbytes = %d\n",nbytes);
					kipcp->molmsg.mnxmsg.m_type = EINVAL;
					send_ack( (COPYOUT | ACKNOWLEDGE));
					}
				else
					{
					kipcp->molmsg.mnxmsg.m_type = OK;
					send_ack( (COPYOUT | ACKNOWLEDGE));
					strncpy(&buffer, "ABCDEFGHIJKLMNOPQRS", nbytes);  /* SOLO PARA PROBAR */
					rcode = data_send(kipcp,(char*) buffer, nbytes);
					}
				break;			
			default:
				MOLPRINT("Bad request: %X\n",rqst);
				break;			
			}
		}

}	

/*----------------------------------------------------------*/
/* 	send_ack	     				*/
/*----------------------------------------------------------*/
int send_ack(int code)
{
    int rcode;
	ipc_t *kipcp;
	mol_proc_t *mpp;

	mpp 	= &mnxproc;
	kipcp	= &mpp->kipc;
	
	/* Send a HELLO ack to MOLKERNEL */
	kipcp->molmsg.code = code;
	kipcp->molmsg.spid = mpp->p_pid;
	kipcp->molmsg.seq  = 0;
	kipcp->molmsg.p_nr = mpp->p_nr; 
	kipcp->molmsg.p_endpoint = mpp->p_endpoint; 
	kipcp->molmsg.srcdst = 0;
MOLDEBUG("code=%X spid=%d seq=%ld p_nr=%d p_enpoint=%d srcdst=%d\n",
                kipcp->molmsg.code,
                kipcp->molmsg.spid,
                kipcp->molmsg.seq,
                kipcp->molmsg.p_nr,
                kipcp->molmsg.p_endpoint,
				kipcp->molmsg.srcdst);
				
	rcode = ipc_send(kipcp);
	if( rcode != OK)
		MOLERROR("ipc_send rcode=%X\n", rcode);
	return(OK);
}

/*----------------------------------------------------------*/
/*		SIGNAL HANDLER SIGUSR1	     				*/
/*----------------------------------------------------------*/
void sigusr1(int sig)
{
	MOLPRINT("SIGUSR1 HANDLER: sig=%d\n",sig);
}

/*	defaultSigHandler(sig):
	Emula el comportamiento por defecto en MINIX de todas las se�ales.
	En caso de ser una se�al que provoca terminaci�n hacer la desregistracion con molkernel.
*/
void defaultSigHandler(int sig)
{
/* 	TODO: solo hace el unbind en caso de ser una se�al matadora. */
	MOLPRINT("This is Mol default signal handler.\n");
	if (	(sig == SIGINT)		||
			(sig == SIGQUIT)	||
			(sig == SIGILL)		||
			(sig == SIGFPE)		||
			(sig == SIGSEGV)	||
			(sig == SIGPIPE)	||
			(sig == SIGALRM)	||
			(sig == SIGTERM)	||
			(sig == SIGUSR2)	
		)
		{
			MOLPRINT("MoL's default action for signal [%d] is dying... bye.\n",sig);
			mol_after();	
			exit(0);
		}
}	

/*	handle_SIGFPE():
	ejecuta el handler de usuario MINIX en forma controlada.
*/
void handle_SIGFPE(void)
{
	/* we do what we want BEFORE user handle here... 
		before_SIGFPE()....
	*/
	MOLPRINT("This is Mol handler for SIGFPE.\n");
	
	/* execute user installed handler for SIGFPE */
	(mnx_sa[SIGFPE-1].sa.sa_handler)(SIGFPE);
		
	/* we do what we want AFTER user handle here... 
		after_SIGFPE()....
	*/
	MOLPRINT("User hanlder for SIGFPE executed. Resuming operations...\n");
	return;
}

/*	handle_SIGINT():
	ejecuta el handler de usuario MINIX en forma controlada.
*/
void handle_SIGINT(void)
{
	/* we do what we want BEFORE user handle here... 
		before_SIGFPE()....
	*/
	MOLPRINT("This is Mol handler for SIGINT.\n");
	
	/* execute user installed handler for SIGFPE */
	(mnx_sa[SIGINT-1].sa.sa_handler)(SIGINT);
		
	/* we do what we want AFTER user handle here... 
		after_SIGFPE()....
	*/
	MOLPRINT("User hanlder for SIGINT executed. Resuming operations...\n");
	return;
}		

/*	molSigHandler(sig):
	Deriva a (1) la ejecuci�n de handler por defecto de MoL o a (2) la ejecucion controlada
	por MoL del handler instalado por el usuario MINIX
*/
static void molSigHandler(int sig)
{
	MOLPRINT("Signal [%d] caught by MoL\n", sig);
	
	if(mnx_sa[sig-1].installed == 1) {
		/* execute user installed handler */
		MOLPRINT("User code installed handler found for signal [%d]. Executing...\n", sig);
		switch(sig) {
			case SIGFPE:
				handle_SIGFPE();
				break;
			case SIGINT:
				handle_SIGINT();
				break;
			default:
				MOLPRINT("User code handle of signal[%d] not implemented in MoL yet.\n", sig);
				break;
		}
	} else 
		defaultSigHandler(sig);
	
	return;                 /* Resume execution at point of interruption */
}

/* installs default MoL handler */
void setSigHandler(int sig)
{
	struct sigaction sa;
	
	sa.sa_handler = molSigHandler;
	
	MOLPRINT("Set MoL signal handler[%d]: ", sig);
	if (sigaction(sig, &sa, &lnx_sa[sig-1]) == -1)
		printf("<Error>\n");
	else
		printf("<OK>\n");
		
}

