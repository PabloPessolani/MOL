/******************************************************************/
/* 				SVRIPC.H						*/
/******************************************************************/

_PROTOTYPE(int svr_open,	(ipc_t *ctrl_ipc, ipc_t *ipc_ipc));
_PROTOTYPE(int svr_send,	(ipc_t *pipc));
_PROTOTYPE(int svr_rcv,		(ipc_t *pipc));
_PROTOTYPE(int svr_close,	(ipc_t *ctrl_ipc, ipc_t *ipc_ipc));
_PROTOTYPE(int svr_data_send, (ipc_t *ctrl_ipc, char* buf_ptr, int nbytes));
_PROTOTYPE(int svr_data_rcv, (ipc_t *ctrl_ipc, char* buf_ptr, int nbytes));

