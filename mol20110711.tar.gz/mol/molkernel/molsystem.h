/******************************************************************/
/**				MOLSYSTEM.H						**/
/******************************************************************/

/* Timers should be initialized once before they are being used. Be careful
* not to reinitialize a timer that is in a list of timers, or the chain
* will be broken.
*/
//#define tmr_inittimer(tp) (void)((tp)->tmr_exp_time = TMR_NEVER, (tp)->tmr_next = NULL)

void *systask_thread(void *arg);
int init_systask(void);

//int do_setalarm(ipc_t *pipc);
int do_times(message *m_ptr);
int do_hello(void);
