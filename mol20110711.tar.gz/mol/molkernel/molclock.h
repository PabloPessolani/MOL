/******************************************************************/
/* 				MOLCLOCK.H						*/
/******************************************************************/

#define SYNC_SECS		60L

#define TIMEOUT_SECS	10

#define INTERVAL_SECS	1
#define INTERVAL_USECS	0

void init_clock(void);
static void clock_handler(int sig);
int set_clock_handler(void);
int do_clocktick(ipc_t *pipc);
void do_synclinux(void);
long walltime(void);
clock_t get_uptime(void);