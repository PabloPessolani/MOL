
User process
============

----------------------------------------------------------
main()
{
	getpid();
}
----------------------------------------------------------

getpid se interceptar� utilizando molcalls.o pero seteando el 
environment
----------------------------------------------------------
LD_PRELOAD=../mollib/libmollib.so:../mnxipc/libmnxipc.so:../molipc/libmolipc.so  ./moltest----------------------------------------------------------

MOLCALLS.O
==========
la libreria donde se captura la funcion getpid
----------------------------------------------------------
getpid() /* falso getpid de LINUX con el mismo nombre */
{
	/* getpid original de LINUX */
	FP_getpid org_getpid = dlsym(((void *) -1l), "getpid"); 
	
	/* getpid de MINIX definido en la biblioteca lib/posix */
	return (_getpid () ); 
}
----------------------------------------------------------

 
MOLLIB
======
intercepta las funciones 
mol_before(): antes de main
mol_after():despues de main

mol_before:
 	- define una estructura ipc para las comunicaciones via sockets (PROBLEMA)
	- ejecuta ipc_open (molipc.c) que inicializa los sockets
	- ejecuta mnx_bind que registra el proceso en KMINIXD

mol_after()
	- ejecuta mnx_unbind que deregistra el proceso en KMINIXD
	- ejecuta ipc_close (molipc.c) que cierra los sockets
	  
MNXLIBC.A
==========
Es la biblioteca posix de MINIX donde est�n las llamadas a funciones.

por ejemplo
----------------------------------------------------------
#include <lib.h>
#define getpid	_getpid
#include <unistd.h>
PUBLIC pid_t getpid()
{
  message m;
  return(_syscall(MM, GETPID, &m));
}
----------------------------------------------------------

se debe resolver el tema de los <XXX.h>

la funcion _syscall se define en \lib\other\syscall.c
----------------------------------------------------------
#include <lib.h>
PUBLIC int _syscall(who, syscallnr, msgptr)
int who;
int syscallnr;
register message *msgptr;
{
  int status;

  msgptr->m_type = syscallnr;
  status = _sendrec(who, msgptr); <<<<<<<< _sendrec
  if (status != 0) {
	/* 'sendrec' itself failed. */
	/* XXX - strerror doesn't know all the codes */
	msgptr->m_type = status;
  }
  if (msgptr->m_type < 0) {
	errno = -msgptr->m_type;
	return(-1);
  }
  return(msgptr->m_type);
}
----------------------------------------------------------





