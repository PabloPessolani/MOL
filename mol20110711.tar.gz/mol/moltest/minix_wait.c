/****************************************************************************/
/**	this is a Minix program dividing by zero and catching the SIGFPE signal */
/****************************************************************************/

#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <signal.h>


void sigHandler(int sig)
{
	printf("U cannot kill with SIGINT on this MINIX ;)\n");
	return;                 /* Resume execution at point of interruption */
}

int main(int argc, char* argv)
{
	
	printf("MINIX: Installing MINIX handler for signal %d...\n", SIGINT);
	if (signal(SIGINT, sigHandler) == SIG_ERR)
		printf("MINIX: <Error>\n");
	else
		printf("MINIX: <OK>\n");
	printf("MINIX: Waiting for signal..\n");
	pause();
	
	printf("Do we reach here??\n");
}




