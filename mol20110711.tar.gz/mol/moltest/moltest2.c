/*
 * moltest.c
 *
 *  Created on: Jul 25, 2010
 *      Author: pirulo
 */

#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>

#include "../include/mol/molstd.h"

int main(int argc, char *argv []);

int main(argc, argv)
	int argc;char *argv[]; {
	int pid, child;

	child = fork();
	if (child == 0)
		{
		pid = getpid();
		printf("MOLTEST: CHILD My pid is %d\n", pid);
		}
	else
		{
		pid = getpid();
		printf("MOLTEST: PARENT My child's pid is %d\n", child);
		}
		
	exit(0);
}


