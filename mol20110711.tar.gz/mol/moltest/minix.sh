#!/bin/sh -e
export PS2='minix:' 
export LD_PRELOAD=../mollib/libmollib.so:../mnxipc/libmnxipc.so:../molipc/libmolipc.so 
/bin/sh
exit
