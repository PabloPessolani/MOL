/*
 * moltest.c
 *
 *  Created on: Jul 25, 2010
 *      Author: pirulo
 */

#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>

#include "../include/mol/molstd.h"

int main(int argc, char *argv []);

int main(argc, argv)
	int argc;char *argv[]; {
	int pid;
	int divzero;

	pid = getpid();
	printf("MOLTEST: My pid is %d\n", pid);

	sleep(2); // <-- enviar una termination se�al (ej. SIGILL) mientras duerme
 
	divzero = 1/0;
	printf("MOLTEST: Exiting gracefully");

	exit(0);
}


