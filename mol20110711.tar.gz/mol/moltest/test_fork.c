/*
 * test_fork.c
 *
 *  Created on: Jun 26, 2011
 *      Author: pirulo
 */

#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>

#include "../include/mol/molstd.h"

int main(int argc, char *argv []);

int main(argc, argv)
	int argc;char *argv[]; {
	int pid;

	pid = fork();
	if(pid == 0)
		printf("TEST_FORK: SON returned pid is %d\n", pid);
	else
		printf("TEST_FORK: FATHER returned pid is %d\n", pid);
	
	printf("TEST_FORK: sleeping 60 secs to wait for HELLO\n");
	
sleep(60);
	printf("TEST_FORK: Exiting gracefully");

	exit(0);
}


