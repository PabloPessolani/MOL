/****************************************************************************/
/**	this is a Minix program dividing by zero and catching the SIGFPE signal */
/****************************************************************************/

#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <signal.h>


void sigHandler(int sig)
{
	printf("U cannot divide by zero on MINIX ;)\n");
	return;                 /* Resume execution at point of interruption */
}

int main(int argc, char* argv)
{
	int divzero;
	int a,b;
	a = 10;
	b = 0;
	
	printf("MINIX: Installing MINIX handler for signal %d...\n", SIGFPE);
	if (signal(SIGFPE, sigHandler) == SIG_ERR)
		printf("MINIX: <Error>\n");
	else
		printf("MINIX: <OK>\n");

	divzero = a/b;
	
	
	sleep(60);
	printf("Do we reach here??\n");
}




