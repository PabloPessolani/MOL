/*
 * test_getpid.c
 *
 *  Created on: Jul 25, 2010
 *      Author: pirulo
 */

#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>

#include "../include/mol/molstd.h"

int main(int argc, char *argv []);

int main(argc, argv)
	int argc;char *argv[]; {
	int pid;

	pid = getpid();
	printf("TEST_GETPID: My MoL pid is %d\n", pid);

	printf("TEST_GETPID: sleeping 60 secs to wait for HELLO\n");
sleep(60);
	printf("TEST_GETPID: Exiting gracefully");

	exit(0);
}


