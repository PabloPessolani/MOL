#include <dlfcn.h> 
#include <stdio.h> 
#include <stdlib.h>
#include <unistd.h>


/******************************************************************/
/*		REPLACEMENT OF MINIX LIBC LIBRARY				*/
/* It intercepts LINUX System Calls through the environment 	*/
/* variable #export LD_PRELOAD=$LD_PRELOAD:./mnxlibc.so		*/
/******************************************************************/

typedef int (*lnx_getpid)(void); /* original LINUX getpid		*/

/*----------------------------------------------------------------*/
/* 			MINIX		GETPID					*/
/*----------------------------------------------------------------*/
int getpid(void)  
{ 
	return(_getpid()); /* invokes minix library compiled under linux */
} 
