/* molpm.c: 
 *
 * MINIX PROCESS MANAGER KERNEL 
 */
/*---------------------- LINUX HEADERS ---------------------------*/
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <time.h>
#include <signal.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

/*----------------------------------------- MINIX HEADERS ---------------------------------*/

#include "../include/minix/config.h" 	
#include "../include/minix/com.h" 
#include "../include/minix/callnr.h"

/*
#define CHIP INTEL
#include "../include/minix/const.h" 
#include "timers.h"
#include "mproc.h"
*/

/*----------------------------------------- MOL HEADERS ---------------------------------*/
#define MOLDBG 1
#include "../include/mol/molminix.h" 
#include "../include/mol/mollib.h" 
#include "../include/mol/molerr.h" 


#include "param.h"
#include "signal.h" 

#include "glo.h"
#include "mproc.h"
#include "proto.h"
#include "pm.h"

pthread_t 	pmc_tid;			/* Container  thread ID  */
struct sigaction lnx_sa[NSIG]; /* we store original linux sigactions here to exec before dying on a terminating signal (eg. SIGILL) */
/* we store handler installed by minix user code */ 
mnx_sa_t mnx_sa[NSIG];

void sigusr1(int sig);
void setSigHandler(int sig);
static void molSigHandler(int sig);
void defaultSigHandler(int sig);
void handle_SIGFPE(void);
void handle_SIGINT(void);
void *container_thread(void *arg);
void exit_molpm(void);
void pm_init(void);

/******************************************************************/
/*				MOLPM						*/			
/******************************************************************/
int main(int argc,char **argv) 
{
   	int rcode,result,proc_nr;
   	int rqst, rply, srcdst;
	message msg;
	mol_proc_t  *mpmp;   	
	mnxsigset_t pmsigset;
	struct mproc *rmp;

	pm_init();

	mpmp = &pmproc;
		
MOLDEBUG("MOLPM: Starting...  name=%s pid=%d\n",mpmp->p_name,mpmp->p_pid);

   	while (TRUE) 
		{
		do	{
			rcode = get_work();		/* fills call_nr, who_p and who_e */
			if( rcode != OK)
				MOLPRINT("get_work rcode=%d\n",rcode);	
			} while(rcode != OK);

		/* Check for system notifications first. Special cases. */
MOLDEBUG("Request received from who_p=%d who_p=%d call_nr=%d\n",who_p,who_e,call_nr);
		switch(call_nr)
			{
			case SYN_ALARM:
				pm_expire_timers(m_in.NOTIFY_TIMESTAMP);
				result = SUSPEND;		/* don't reply */
				break;
			case SYS_SIG:
				pmsigset = m_in.NOTIFY_ARG;
			/*	if (mnxsigismember(&pmsigset,SIGKSIG))  
					ksig_pending();
			*/
				result = SUSPEND;		/* don't reply */
				break;
			default:	/* if the system call number is valid, perform the call. */
				if ( (call_nr >= NCALLS) || (call_nr < 0))
					result = EMOLNOSYS;
				else 
					{
MOLDEBUG("Calling call_vec[%d]\n",call_nr);
					result = (*call_vec[call_nr])();
					}
				break;
			}

MOLDEBUG("result =%d\n",result);
		/* Send the results back to the user to indicate completion. */
		if (result != SUSPEND) 
			setreply(who_p, result);

		/* swap_in();	NOT IMPLEMENTED  maybe a process can be swapped in? */

		/* Send out all pending reply messages, including the answer to
	 	* the call just made above.  The processes must not be swapped out.
		*/

		/*
		for (proc_nr=0, rmp=mproc; proc_nr < NR_PROCS; proc_nr++, rmp++) 
			{
			if ((rmp->mp_flags & (REPLY | ONSWAP | IN_USE | ZOMBIE)) == (REPLY | IN_USE)) 
				{
				*/
				if (result != SUSPEND) /* ESTE IF ES TEMPORAL*/
					{
					rmp = &mproc[who_p]; /* TEMPORAL */
					rcode = mini_send(rmp->mp_endpoint, &rmp->mp_reply);
					if (rcode != OK) 
						MOLPRINT("PM can't reply to %d (%s)\n",	rmp->mp_endpoint, rmp->mp_name);
					rmp->mp_flags &= ~REPLY;
					}
				/*
				}
			}
		*/
		}
}

/*===========================================================================*
 *				get_work				     *
 *===========================================================================*/
int get_work(void)
{
   	int rcode;
	mol_proc_t  *mpmp;   	

	mpmp = &pmproc;

MOLDEBUG("Waiting Request message...\n");
	do 	{
		rcode = mini_receive(ANY, &m_in);
		if( rcode != OK)
			MOLPRINT("mini_receive rcode=%d\n",rcode);
		} while(rcode != OK);

	who_e = m_in.m_source;					
	if(pm_isokendpt(who_e, &who_p) != OK)
		{
		MOLPRINT("PM got message from invalid endpoint %d\n", who_e);
		return(EMOLBADSRCDST);
		}

	call_nr = m_in.m_type;				
	mp = &mproc[who_p < 0 ? PM_PROC_NR : who_p];
	
/*------------------------------ temporalmente invalidado------------------------------------
	if(who_p >= 0 && mp->mp_endpoint != who_e) 
		{
		MOLPRINT("PM endpoint number out of sync with source %d\n",mp->mp_endpoint);
		return(EMOLDEADSRCDST);
		}
---------------------------------------------------------------------------------------------------*/
		return(OK);
}

/*----------------------------------------------------------*/
/*			pm_init						*/
/*----------------------------------------------------------*/
void pm_init()
{
	int rcode;
	mol_proc_t *mpp;
	int i;
	int 	idx;
	struct mproc *rmp;


MOLDEBUG("\n");
	mpp = &pmproc;

	/*------- initialize IPC communications --------------*/
	mpp->p_pid = getpid();
   	strncpy(mpp->p_name,"pm",P_NAME_LEN);
	rcode = ipc_open(mpp, MOLKERNEL_ADDR, MOLKERNEL_PORT);
	if(rcode != OK)
		MOLERROR("error=%d \n",rcode);
		
	/*------- Register the process on MOLKERNEL-------------*/
	rcode = mnx_bind(mpp);
	if(rcode != OK)
		MOLERROR("error=%d \n",rcode);
		
/*----------------- EMULATE PM HERE -------------------------------*/

	/* Initialize process table, including timers. */
	MOLPRINT("Building process table:");		/* show what's happening */
	procs_in_use = 0;						/* start populating table */

	for (rmp=&mproc[0]; rmp<&mproc[NR_PROCS]; rmp++)
		{ 
		tmr_inittimer(&rmp->mp_timer);/* definida en include/timers.h	*/
  		strncpy(rmp->mp_name, "FREE", P_NAME_LEN); 
  		mnxsigemptyset(&rmp->mp_sig2mess);
  		mnxsigemptyset(&rmp->mp_ignore);	
  		mnxsigemptyset(&rmp->mp_sigmask);
  		mnxsigemptyset(&rmp->mp_catch);
		rmp->mp_endpoint = NONE;
		}

/*----------------- UNTIL HERE ----------------------------------------*/

	/*------- Sets the Signal Action for killer signals---------*/
	
	/* init sa arrays */
	for(i = 0; i < NSIG; i++)
		mnx_sa[i].installed = 0;
		
	/* set default MoL handler for all signals */
	for(i = 1; i <= NSIG; i++)
		setSigHandler(i);

	/*---------------- Start Container  thread  ----------------------*/

	rcode = pthread_create(&pmc_tid, NULL, container_thread, &idx);
	if (rcode != 0)
		MOLERROR("pthread_create rcode=%d\n",rcode);

} 


/*----------------------------------------------------------*/
/*			exit_molpm						*/
/*----------------------------------------------------------*/
void exit_molpm()
{ 
	int rcode;
	mol_proc_t *mpp;

MOLDEBUG("\n"); 
	mpp = &pmproc;
	
	/*------- Deregister the process on MOLKERNEL-----------*/
	rcode = mnx_unbind(mpp);
	if(rcode != OK)
		MOLERROR("error=%d \n",rcode);

	/*--------------- End IPC communications -------------*/

	rcode = ipc_close(mpp);
	if(rcode != OK)
		MOLERROR("error= %d \n",rcode);

} 

/*----------------------------------------------------------*/
/* 	send_copyinack	     				*/
/*----------------------------------------------------------*/
int send_copyinack()
{
    int rcode;
	int rqst;
	ipc_t *kipcp;
	mol_proc_t *mpp;

	mpp 	= &pmproc;
	kipcp	= &mpp->kipc;
	
	/* Send a HELLO ack to MOLKERNEL */
	kipcp->molmsg.code = (COPYIN | ACKNOWLEDGE);
	kipcp->molmsg.spid = mpp->p_pid;
	kipcp->molmsg.seq  = 0;
	kipcp->molmsg.p_nr = mpp->p_nr; 
	kipcp->molmsg.p_endpoint = mpp->p_endpoint; 
	kipcp->molmsg.srcdst = 0;
MOLDEBUG("code=%X spid=%d seq=%ld p_nr=%d p_enpoint=%d srcdst=%d\n",
                kipcp->molmsg.code,
                kipcp->molmsg.spid,
                kipcp->molmsg.seq,
                kipcp->molmsg.p_nr,
                kipcp->molmsg.p_endpoint,
				kipcp->molmsg.srcdst);
				
	rcode = ipc_send(kipcp);
	if( rcode != OK)
		MOLERROR("ipc_send rcode=%X\n", rcode);
	return(OK);
}

/*----------------------------------------------------------*/
/* 	send_hellock	     				*/
/*----------------------------------------------------------*/
int send_helloack()
{
    int rcode;
	int rqst;
	ipc_t *kipcp;
	mol_proc_t *mpp;

	mpp 	= &pmproc;
	kipcp	= &mpp->kipc;
	
	/* Send a HELLO ack to MOLKERNEL */
	kipcp->molmsg.code = (HELLO | ACKNOWLEDGE);
	kipcp->molmsg.spid = mpp->p_pid;
	kipcp->molmsg.seq  = 0;
	kipcp->molmsg.p_nr = mpp->p_nr; 
	kipcp->molmsg.p_endpoint = mpp->p_endpoint; 
	kipcp->molmsg.srcdst = 0;
MOLDEBUG("code=%X spid=%d seq=%ld p_nr=%d p_enpoint=%d srcdst=%d\n",
                kipcp->molmsg.code,
                kipcp->molmsg.spid,
                kipcp->molmsg.seq,
                kipcp->molmsg.p_nr,
                kipcp->molmsg.p_endpoint,
				kipcp->molmsg.srcdst);
				
	rcode = ipc_send(kipcp);
	if( rcode != OK)
		MOLERROR("ipc_send rcode=%X\n", rcode);
	return(OK);
}


/*----------------------------------------------------------*/
/*	CONTAINER THREAD FUNCTION	      */
/*----------------------------------------------------------*/
void *container_thread(void *arg)
{
    int rcode;
	int rqst;
	ipc_t *kipcp;
	
	kipcp=&pmproc.kipc;
	
	MOLDEBUG("CONTAINER THREAD Starting\n");

		while (TRUE) 
		{
MOLPRINT("Waiting Request message...\n");
		rcode = ipc_rcv(kipcp);
		if ( rcode != OK) continue;
		
		rqst 	= kipcp->molmsg.code;
		switch(rqst)
			{
			case HELLO:
MOLDEBUG("HELLO message received\n");
				send_helloack();
				break;
			case COPYIN:
MOLDEBUG("COPYIN message received\n");
				send_copyinack();
				break;
			default:
				MOLPRINT("Bad request: %X\n",rqst);
				break;			
			}
		}
		
}	

/*----------------------------------------------------------*/
/*		SIGNAL HANDLER SIGUSR1	     				*/
/*----------------------------------------------------------*/
void sigusr1(int sig)
{
	MOLPRINT("SIGUSR1 HANDLER: sig=%d\n",sig);
}

/*	defaultSigHandler(sig):
	Emula el comportamiento por defecto en MINIX de todas las se�ales.
	En caso de ser una se�al que provoca terminaci�n hacer la desregistracion con molkernel.
*/
void defaultSigHandler(int sig)
{
/* 	TODO: solo hace el unbind en caso de ser una se�al matadora. */
	MOLPRINT("This is Mol default signal handler.\n");
	if (	(sig == SIGINT)		||
			(sig == SIGQUIT)	||
			(sig == SIGILL)		||
			(sig == SIGFPE)		||
			(sig == SIGSEGV)	||
			(sig == SIGPIPE)	||
			(sig == SIGALRM)	||
			(sig == SIGTERM)	||
			(sig == SIGUSR2)	
		)
		{
			MOLPRINT("MoL's default action for signal [%d] is dying... bye.\n",sig);
			exit_molpm();	
			exit(0);
		}
}	

/*	handle_SIGFPE():
	ejecuta el handler de usuario MINIX en forma controlada.
*/
void handle_SIGFPE(void)
{
	/* we do what we want BEFORE user handle here... 
		before_SIGFPE()....
	*/
	MOLPRINT("This is Mol handler for SIGFPE.\n");
	
	/* execute user installed handler for SIGFPE */
	(mnx_sa[SIGFPE-1].sa.sa_handler)(SIGFPE);
		
	/* we do what we want AFTER user handle here... 
		after_SIGFPE()....
	*/
	MOLPRINT("User hanlder for SIGFPE executed. Resuming operations...\n");
	return;
}

/*	handle_SIGINT():
	ejecuta el handler de usuario MINIX en forma controlada.
*/
void handle_SIGINT(void)
{
	/* we do what we want BEFORE user handle here... 
		before_SIGFPE()....
	*/
	MOLPRINT("This is Mol handler for SIGINT.\n");
	
	/* execute user installed handler for SIGFPE */
	(mnx_sa[SIGINT-1].sa.sa_handler)(SIGINT);
		
	/* we do what we want AFTER user handle here... 
		after_SIGFPE()....
	*/
	MOLPRINT("User hanlder for SIGINT executed. Resuming operations...\n");
	return;
}		

/*	molSigHandler(sig):
	Deriva a (1) la ejecuci�n de handler por defecto de MoL o a (2) la ejecucion controlada
	por MoL del handler instalado por el usuario MINIX
*/
static void molSigHandler(int sig)
{
	MOLPRINT("Signal [%d] caught by MoL\n", sig);
	
	if(mnx_sa[sig-1].installed == 1) {
		/* execute user installed handler */
		MOLPRINT("User code installed handler found for signal [%d]. Executing...\n", sig);
		switch(sig) {
			case SIGFPE:
				handle_SIGFPE();
				break;
			case SIGINT:
				handle_SIGINT();
				break;
			default:
				MOLPRINT("User code handle of signal[%d] not implemented in MoL yet.\n", sig);
				break;
		}
	} else 
		defaultSigHandler(sig);
	
	return;                 /* Resume execution at point of interruption */
}

/* installs default MoL handler */
void setSigHandler(int sig)
{
	struct sigaction sa;
	
	sa.sa_handler = molSigHandler;
	
	MOLPRINT("Installing default MoL handler for signal %d...\t", sig);
	if (sigaction(sig, &sa, &lnx_sa[sig-1]) == -1)
		printf("<Error>\n");
	else
		printf("<OK>\n");
		
}

  