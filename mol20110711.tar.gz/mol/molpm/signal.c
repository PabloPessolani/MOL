#include "pm.h"
#include "signal.h" 
/* Low bit of signal masks. */

#include "../include/mol/molerr.h" 

#define SIGBIT_0	((mnxsigset_t) 1)

/* Mask of valid signals (0 - _NSIG). */
#define SIGMASK		(((SIGBIT_0 << _NSIG) << 1) - 1)

#define mnxsigisvalid(signo) ((unsigned) (signo) <= _NSIG)
int errno;

int mnxsigaddset(mnxsigset_t *set, int signo)
{
  if (!mnxsigisvalid(signo)) {
  	errno = EMOLINVAL;
	return -1;
  }
  *set |= SIGBIT_0 << signo;
  return 0;
}

int mnxsigdelset(mnxsigset_t *set, int signo)

{
  if (!mnxsigisvalid(signo)) {
  	errno = EMOLINVAL;
	return -1;
  }
  *set &= ~(SIGBIT_0 << signo);
  return 0;
}

int mnxsigemptyset(mnxsigset_t *set)
{
  *set = 0;
  return 0;
}

int mnxsigfillset(mnxsigset_t *set)
{
  *set = SIGMASK;
  return 0;
}

int mnxsigismember(mnxsigset_t *set, int signo)
{
  if (!mnxsigisvalid(signo)) {
  	errno = EMOLINVAL;
	return -1;
  }
  if (*set & (SIGBIT_0 << signo))
  	return 1;
  return 0;
}
