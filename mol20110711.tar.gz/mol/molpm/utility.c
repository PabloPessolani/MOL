/*---------------------- LINUX HEADERS ---------------------------*/
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <time.h>
#include <signal.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

/*----------------------------------------- MINIX HEADERS ---------------------------------*/

#include "../include/minix/config.h"
#include "../include/minix/endpoint.h" 	
#include "../include/minix/com.h" 
#include "../include/minix/callnr.h"
#include "../include/minix/const.h"
#include "../include/signal.h" 

/*
#define CHIP INTEL
#include "../include/minix/const.h" 
#include "timers.h"
#include "mproc.h"
*/

/*----------------------------------------- MOL HEADERS ---------------------------------*/
#define MOLDBG 1
#include "../include/mol/molminix.h" 
#include "../include/mol/mollib.h" 
#include "../include/mol/molerr.h" 

#include "const.h"
#include "glo.h"
#include "mproc.h"
#include "param.h"
#include "pm.h"


/*===============================================================*
 *				no_sys					     *
 *===============================================================*/
int no_sys()
{
	/* A system call number not implemented by PM has been requested. */
MOLPRINT("A system call number not implemented by PM has been requested\n",call_nr);
  	return(EMOLNOSYS);
}


/*===========================================================================*
 *                               sys_setalarm		     	     	     *
 *===========================================================================*/
int sys_setalarm(clock_t exp_time, int abs_time)
{
/* Ask the SYSTEM schedule a synchronous alarm for the caller. The process
 * number can be SELF if the caller doesn't know its process number.
 */
 	mol_proc_t  *mpmp;   	
    message m;

	mpmp = &pmproc;

    m.m_type = SYS_SETALARM;	
    m.ALRM_EXP_TIME = exp_time;		/* the expiration time */
    m.ALRM_ABS_TIME = abs_time;		/* time is absolute? */
    return(mini_sendrec(SYSTEM, &m));
}

/**===========================================================================*
 *				pm_isokendpt			 	     *
 *===========================================================================*/
int pm_isokendpt(int endpoint, int *proc)
{
	*proc = _ENDPOINT_P(endpoint);
/*
	if(*proc < -NR_TASKS || *proc >= NR_PROCS)
		return EMOLINVAL;
	if(*proc >= 0 && endpoint != mproc[*proc].mp_endpoint)
		return EMOLDEADSRCDST;
	if(*proc >= 0 && !(mproc[*proc].mp_flags & IN_USE))
		return EMOLDEADSRCDST;
*/
	return OK;
}


/*===========================================================================*
 *				setreply				     *
 *===========================================================================*/
void setreply(int proc_nr, int result)
{
/* Fill in a reply message to be sent later to a user process.  System calls
 * may occasionally fill in other fields, this is only for the main return
 * value, and for setting the "must send reply" flag.
 */
	struct mproc *rmp;

	MOLDEBUG(" proc_nr=%d result=%d\n", proc_nr, result);

	if(proc_nr < 0 || proc_nr >= NR_PROCS)
      MOLERROR("setreply arg out of range", proc_nr);

	rmp = &mproc[proc_nr];
	rmp->mp_reply.reply_res = result;
	rmp->mp_flags |= REPLY;	/* reply pending */
  
    rmp->mp_endpoint = who_e; /* <<<<<<<<<< TEMPORAL <<<<<<<<<<<<<<*/
	rmp->mp_reply.m_source = PM_PROC_NR;
/*
  if (rmp->mp_flags & ONSWAP)
	swap_inqueue(rmp);	
*/
}


/*===========================================================================*
 *				tell_fs					     *
 *===========================================================================*/
void tell_fs(int what, int p1, int p2, int  p3)
{
/* This routine is only used by PM to inform FS of certain events:
 *      tell_fs(CHDIR, slot, dir, 0)
 *      tell_fs(EXEC, proc, 0, 0)
 *      tell_fs(EXIT, proc, 0, 0)
 *      tell_fs(FORK, parent, child, pid)
 *      tell_fs(SETGID, proc, realgid, effgid)
 *      tell_fs(SETSID, proc, 0, 0)
 *      tell_fs(SETUID, proc, realuid, effuid)
 *      tell_fs(UNPAUSE, proc, signr, 0)
 *      tell_fs(STIME, time, 0, 0)
 * Ignore this call if the FS is already dead, e.g. on shutdown.
 */
 	mol_proc_t  *mpmp;   	
    message m;

	mpmp = &pmproc;

  if ((mproc[FS_PROC_NR].mp_flags & (IN_USE|ZOMBIE)) != IN_USE)
      return;

    m.m_type = what;	
	m.tell_fs_arg1 = p1;
	m.tell_fs_arg2 = p2;
	m.tell_fs_arg3 = p3;
  return(mini_sendrec(FS_PROC_NR, &m));
}
  
  

/*===========================================================================*
 *				get_free_pid				     *
 *===========================================================================*/
pid_t get_free_pid()
{
  static pid_t next_pid = INIT_PID + 1;	/* next pid to be assigned */
  register struct mproc *rmp;			/* check process table */
  int t;						/* zero if pid still free */

  /* Find a free pid for the child and put it in the table. */
  do {
	t = 0;			
	next_pid = (next_pid < NR_PIDS ? next_pid + 1 : INIT_PID + 1);
	for (rmp = &mproc[0]; rmp < &mproc[NR_PROCS]; rmp++)
		if (rmp->mp_pid == next_pid || rmp->mp_procgrp == next_pid) {
			t = 1;
			break;
		}
  } while (t);					/* 't' = 0 means pid free */
  return(next_pid);
}

/*===========================================================================*
 *				set_alarm				     *
 *===========================================================================*/
int set_alarm(proc_nr_e, sec)
int proc_nr_e;			/* process that wants the alarm */
int sec;			/* how many seconds delay before the signal */
{
/* This routine is used by do_alarm() to set the alarm timer.  It is also used
 * to turn the timer off when a process exits with the timer still on.
 */
  clock_t ticks;	/* number of ticks for alarm */
  clock_t exptime;	/* needed for remaining time on previous alarm */
  clock_t uptime;	/* current system time */
  int remaining;	/* previous time left in seconds */
  int s;
  int proc_nr_n;

  if(pm_isokendpt(proc_nr_e, &proc_nr_n) != OK)
	return EINVAL;

  /* First determine remaining time of previous alarm, if set. */
  if (mproc[proc_nr_n].mp_flags & ALARM_ON) {
  	if ( (s=getuptime(&uptime)) != OK) 
  		panic(__FILE__,"set_alarm couldn't get uptime", s);
  	exptime = *tmr_exp_time(&mproc[proc_nr_n].mp_timer);
  	remaining = (int) ((exptime - uptime + (HZ-1))/HZ);
  	if (remaining < 0) remaining = 0;	
  } else {
  	remaining = 0; 
  }

  /* Tell the clock task to provide a signal message when the time comes.
   *
   * Large delays cause a lot of problems.  First, the alarm system call
   * takes an unsigned seconds count and the library has cast it to an int.
   * That probably works, but on return the library will convert "negative"
   * unsigneds to errors.  Presumably no one checks for these errors, so
   * force this call through.  Second, If unsigned and long have the same
   * size, converting from seconds to ticks can easily overflow.  Finally,
   * the kernel has similar overflow bugs adding ticks.
   *
   * Fixing this requires a lot of ugly casts to fit the wrong interface
   * types and to avoid overflow traps.  ALRM_EXP_TIME has the right type
   * (clock_t) although it is declared as long.  How can variables like
   * this be declared properly without combinatorial explosion of message
   * types?
   */
  ticks = (clock_t) (HZ * (unsigned long) (unsigned) sec);
  if ( (unsigned long) ticks / HZ != (unsigned) sec)
	ticks = LONG_MAX;	/* eternity (really TMR_NEVER) */

  if (ticks != 0) {
  	pm_set_timer(&mproc[proc_nr_n].mp_timer, ticks,
		cause_sigalrm, proc_nr_e);
  	mproc[proc_nr_n].mp_flags |=  ALARM_ON;
  } else if (mproc[proc_nr_n].mp_flags & ALARM_ON) {
  	pm_cancel_timer(&mproc[proc_nr_n].mp_timer);
  	mproc[proc_nr_n].mp_flags &= ~ALARM_ON;
  }
  return(remaining);
}


#ifdef NATIVO

/*===========================================================================*
 *				allowed					     *
 *===========================================================================*/
PUBLIC int allowed(name_buf, s_buf, mask)
char *name_buf;			/* pointer to file name to be EXECed */
struct stat *s_buf;		/* buffer for doing and returning stat struct*/
int mask;			/* R_BIT, W_BIT, or X_BIT */
{
/* Check to see if file can be accessed.  Return EACCES or ENOENT if the access
 * is prohibited.  If it is legal open the file and return a file descriptor.
 */
  int fd;
  int save_errno;

  /* Use the fact that mask for access() is the same as the permissions mask.
   * E.g., X_BIT in <minix/const.h> is the same as X_OK in <unistd.h> and
   * S_IXOTH in <sys/stat.h>.  tell_fs(DO_CHDIR, ...) has set PM's real ids
   * to the user's effective ids, so access() works right for setuid programs.
   */
  if (access(name_buf, mask) < 0) return(-errno);

  /* The file is accessible but might not be readable.  Make it readable. */
  tell_fs(SETUID, PM_PROC_NR, (int) SUPER_USER, (int) SUPER_USER);

  /* Open the file and fstat it.  Restore the ids early to handle errors. */
  fd = open(name_buf, O_RDONLY | O_NONBLOCK);
  save_errno = errno;		/* open might fail, e.g. from ENFILE */
  tell_fs(SETUID, PM_PROC_NR, (int) mp->mp_effuid, (int) mp->mp_effuid);
  if (fd < 0) return(-save_errno);
  if (fstat(fd, s_buf) < 0) panic(__FILE__,"allowed: fstat failed", NO_NUM);

  /* Only regular files can be executed. */
  if (mask == X_BIT && (s_buf->st_mode & I_TYPE) != I_REGULAR) {
	close(fd);
	return(EACCES);
  }
  return(fd);
}


/*===========================================================================*
 *				panic					     *
 *===========================================================================*/
PUBLIC void panic(who, mess, num)
char *who;			/* who caused the panic */
char *mess;			/* panic message string */
int num;			/* number to go with it */
{
/* An unrecoverable error has occurred.  Panics are caused when an internal
 * inconsistency is detected, e.g., a programming error or illegal value of a
 * defined constant. The process manager decides to exit.
 */
  message m;
  int s;

  /* Switch to primary console and print panic message. */
  check_sig(mproc[TTY_PROC_NR].mp_pid, SIGTERM);
  printf("PM panic (%s): %s", who, mess);
  if (num != NO_NUM) printf(": %d",num);
  printf("\n");
   
  /* Exit PM. */
  sys_exit(SELF);
}



/*===========================================================================*
 *				find_param				     *
 *===========================================================================*/
PUBLIC char *find_param(name)
const char *name;
{
  register const char *namep;
  register char *envp;

  for (envp = (char *) monitor_params; *envp != 0;) {
	for (namep = name; *namep != 0 && *namep == *envp; namep++, envp++)
		;
	if (*namep == '\0' && *envp == '=') 
		return(envp + 1);
	while (*envp++ != 0)
		;
  }
  return(NULL);
}

/*===========================================================================*
 *				get_mem_map				     *
 *===========================================================================*/
PUBLIC int get_mem_map(proc_nr, mem_map)
int proc_nr;					/* process to get map of */
struct mem_map *mem_map;			/* put memory map here */
{
  struct proc p;
  int s;

  if ((s=sys_getproc(&p, proc_nr)) != OK)
  	return(s);
  memcpy(mem_map, p.p_memmap, sizeof(p.p_memmap));
  return(OK);
}

/*===========================================================================*
 *				get_stack_ptr				     *
 *===========================================================================*/
PUBLIC int get_stack_ptr(proc_nr_e, sp)
int proc_nr_e;					/* process to get sp of */
vir_bytes *sp;					/* put stack pointer here */
{
  struct proc p;
  int s;

  if ((s=sys_getproc(&p, proc_nr_e)) != OK)
  	return(s);
  *sp = p.p_reg.sp;
  return(OK);
}

/*===========================================================================*
 *				proc_from_pid				     *
 *===========================================================================*/
PUBLIC int proc_from_pid(mp_pid)
pid_t mp_pid;
{
	int rmp;

	for (rmp = 0; rmp < NR_PROCS; rmp++)
		if (mproc[rmp].mp_pid == mp_pid)
			return rmp;

	return -1;
}

#endif /* NATIVO */
